# MÉTIS Workshop @ MICCAI 2026 — Clinical AI Project Proposal (LaTeX)

LaTeX template for the MÉTIS clinical proposal track.

## Files

| File | Purpose |
|---|---|
| `METIS_Proposal_Template.tex` | The template — this is the file you edit |
| `METIS_Proposal_Template.pdf` | Preview of the blank template |

## Using it

**Overleaf** — New Project → Upload Project → select the `.zip`. Compiles with
pdfLaTeX, no extra setup.

**Locally** — `pdflatex METIS_Proposal_Template.tex` (run twice).

## Two switches in the preamble

```latex
\guidancetrue     % show the grey prompts while drafting
\guidancefalse    % hide them before you submit

\compactfalse     % default spacing   (~650 words on one page)
\compacttrue      % tighter spacing   (~730 words on one page)
```

Set `\guidancefalse` before generating your final PDF, otherwise the
instructions will appear in your submission.

## Length

Target **600–800 words**, excluding references. Per-section budgets are printed
next to each heading. Writing to the full 800 words will run a few lines onto a
second page — that is fine; the limit is on words, not pages.

## Anonymity

Review is **double-blind** via OpenReview. Do not include author names,
institutional affiliations, acknowledgements, funding statements, ethics
approval numbers, or names of collaborating institutions. Cite your own prior
work in the third person.

Before uploading, check that your PDF metadata does not carry your name — in
Overleaf this is clean by default; locally, `pdflatex` may embed your username
via the file path.

## Structure

1. Unmet Clinical Need & Clinical Impact — 150–200 words
2. Proposed AI Solution — 100–150 words
3. Training Data — 100–150 words
4. External Validation & Feasibility — 100–150 words
5. Clinical Integration — 150–200 words

## Contact

mohamed.saadeldin@ucd.ie · aon.safdar@ucdconnect.ie
https://metis-miccai26.github.io/
